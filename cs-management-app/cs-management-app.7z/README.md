

npm install react-chartjs-2 chart.js